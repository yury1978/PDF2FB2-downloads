# Podpis Android 1.1.0

Dostarczany APK instalacyjny jest wariantem **debug**, podpisanym tym samym
lokalnym certyfikatem co udostępnione 1.0.0 (i 0.9.1). Publiczny odcisk SHA-256:
`a00dbe983485808f1a5394a98e2bc8d9b1d9b7c2bbafd3699b1824cfbf3f4675`.
Klucz pozostaje poza repozytorium i archiwum źródłowym. Należy zachować jego
zaszyfrowaną kopię poza tym środowiskiem; utrata klucza uniemożliwia aktualizacje
podpisane tym certyfikatem. Zwykły debug key nie jest kluczem produkcyjnym.

## Przyszły podpis produkcyjny

1. Właściciel generuje i bezpiecznie archiwizuje własny klucz RSA co najmniej
   3072 bitów w prywatnym magazynie. Nie dodaje go ani haseł do Git.
2. Uruchamia testy, Lint i `:app:assembleRelease` (JDK 17, Gradle Wrapper).
3. Kopiuje `app-release-unsigned.apk` do prywatnego katalogu wydania i wykonuje
   `zipalign -P 16 -f 4 app-release-unsigned.apk app-release-aligned.apk`.
4. Podpisuje `apksigner sign --ks /prywatna/sciezka/release.jks --out PDF2FB2-release.apk app-release-aligned.apk`.
   Narzędzie pyta o hasło; nie zapisuje go w poleceniu ani repozytorium.
5. Wykonuje `apksigner verify --verbose --print-certs PDF2FB2-release.apk`,
   `zipalign -c -P 16 4 PDF2FB2-release.apk` i ponawia testy instalacji/OCR offline
   podpisanego artefaktu na urządzeniu. Zapisuje SHA-256 i publiczny certyfikat.

APK z innym certyfikatem **nie aktualizuje** istniejącej instalacji debug.
Przejście wymaga eksportu książek, usunięcia starej aplikacji i instalacji nowej;
usunięcie aplikacji usuwa jej prywatne dane. Nie reklamować tego jako aktualizacji
bez utraty danych. Niepodpisany release APK nie jest gotowy do instalacji.

CI może odzyskać ten sam prywatny debug key z sekretu
`ANDROID_DEBUG_KEYSTORE_BASE64`. Bez sekretu tworzy inny certyfikat, więc
artefakt CI nie gwarantuje aktualizacji zainstalowanego APK. Obecny workflow
nie publikuje aplikacji w sklepie i nie automatyzuje podpisu produkcyjnego.
