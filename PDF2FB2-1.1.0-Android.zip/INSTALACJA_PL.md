# Instalacja PDF2FB2 1.1.0 na Androidzie

Wymagany Android 8.0 lub nowszy (API 26). Pakiet: `pl.pdf2fb2`, versionCode 12.
Obsługiwane ABI: arm64-v8a, armeabi-v7a, x86_64, x86. Modele pol/rus/eng
są dołączone; po instalacji aplikacja działa bez dostępu do internetu.
Pierwsza konwersja OCR kopiuje i sprawdza około 13 MB modeli w pamięci aplikacji.
Zarezerwuj co najmniej 200 MB na instalację i dodatkowe miejsce na kopię PDF,
pliki robocze PDFBox oraz eksport; wielkie PDF wymagają więcej miejsca.

1. Pobierz **PDF2FB2-1.1.0-debug.apk** z zatwierdzonego repozytorium
   https://github.com/yury1978/PDF2FB2-downloads . Plik można też rozpakować z ZIP.
2. Otwórz APK w menedżerze plików. Jeśli Android zapyta, jednorazowo zezwól
   temu menedżerowi/przeglądarce na instalowanie nieznanych aplikacji.
3. Wybierz „Zainstaluj” albo „Aktualizuj”. Po instalacji wyłącz to zezwolenie.
4. W aplikacji wybierz PDF. Tryb automatyczny korzysta z tekstu PDF, a na
   stronach z małą ilością tekstu uruchamia OCR. „Zawsze OCR” wymusza rozpoznawanie.
5. Wybierz język OCR; „Automatycznie” używa wszystkich trzech modeli, co trwa
   dłużej niż jeden język. Język metadanych FB2 wybiera się osobno.
6. Pozostaw „Zachowaj ilustracje” włączone. Domyślna jakość to Wysoka; Oryginalna zwiększa rozmiar FB2. Miniatury pojawią się między akapitami. Ostrzeżenia pokazują pominięcia i niepewne pozycje.
7. Rozpocznij konwersję, sprawdź podgląd i popraw błędy rozpoznawania. Zapisz FB2
   przez systemowy wybór miejsca. Przed zapisem wynik jest walidowany lokalnym XSD.

Przycisk anulowania zatrzymuje konwersję. Wybór nowego PDF anuluje poprzednie
zadanie; jego wynik nie pojawi się jako tekst nowej książki. Obrót ekranu zachowuje
zadanie. Zamknięcie procesu przez Androida nie zachowuje nieeksportowanego tekstu.
Nie uruchamiaj długiego OCR z aplikacją w tle: v1.1 nie ma usługi pierwszoplanowej.

## Aktualizacja i podpis

Przed aktualizacją zapisz otwartą książkę. Android zatrzymuje proces aplikacji,
a v1.0/v1.1 nie utrwalają niezapisanej korekty po jego zamknięciu.

Dostarczany plik jest **debug**, bez produkcyjnego podpisu/Google Play.
Podpis i ograniczenia opisuje SIGNING.md. Ten sam certyfikat co udostępnione
1.0.0 powinien umożliwiać aktualizację; potwierdzenie dla emulatora jest w raporcie.
Użytkownik potwierdził działanie v1.0.0 na telefonie; aktualizację do v1.1.0 przetestowano osobno na emulatorze, nie na tym telefonie.

Komunikat „aplikacja nie została zainstalowana” może oznaczać inny certyfikat,
próbę obniżenia versionCode lub zbyt stary Android. Nie usuwaj poprzedniej
instalacji przed wyeksportowaniem książek. Instalacja pliku release-unsigned
nie jest możliwa. Nie trzeba instalować Termux, Pythona ani pobierać modeli.

## Ograniczenia

OCR może mylić litery i układ stron; korekta pozostaje konieczna. Tekst w dwóch
kolumnach, tabele, odręczne pismo, zły kontrast i nietypowe fonty nie mają
potwierdzonej jakości. Rastry są ograniczone do 4 MP/4096 px i przetwarzane po
jednej stronie. Limit edytowalnego tekstu zależy od pamięci urządzenia (maks. 4 mln
znaków); przekroczenie daje błąd zamiast cichego obcięcia. Eksportowane pliki
pozostają w wybranym przez użytkownika miejscu. Książki nie są wysyłane do sieci.

## Ilustracje i miejsce na dysku

Aplikacja kopiuje PDF oraz zapisuje ilustracje i miniatury w prywatnym katalogu roboczym. Zarezerwuj dodatkowe miejsce na PDF, do 96 MiB obrazów i do 160 MiB wynikowego FB2 oraz pliki robocze dekodera. Bardzo duży PDF może wymagać więcej. Brak miejsca daje błąd/ostrzeżenie; zawsze porównaj liczbę ilustracji i podgląd ze źródłem. Usuń całą miniaturę, jeśli chcesz wykluczyć obraz z eksportu. Podgląd używa miniatur; szczegóły oceniaj w wyeksportowanym FB2.

Skanowana strona pozostaje tekstem OCR. Zdjęcia są wydzielane, gdy Tesseract poda wiarygodny osobny obszar. Złożone skany, kolumny, mapy i diagramy wymagają kontroli; nie obiecujemy automatycznego odtworzenia każdego układu. Dane obrazów są osadzone w jednym FB2.
