# Instalacja i aktualizacja PDF2FB2 2.0.0

Android 8.0 lub nowszy (API 26), pakiet `pl.pdf2fb2`, versionCode 20. APK zawiera lokalny OCR PL/RU/EN oraz biblioteki ARM64, ARMv7, x86_64 i x86. Nie wymaga Termux, Pythona ani pobierania modeli. Pierwszy OCR weryfikuje i kopiuje około 13 MB modeli do prywatnego katalogu aplikacji.

## Instalacja testowa

1. Pobierz **PDF2FB2-2.0.0-debug.apk** z załącznika bieżącej sesji i sprawdź sumę z `SHA256SUMS.txt`. Sam tekst `/workspace/...` ze starszej rozmowy nie jest serwerem pobierania. Jeśli klient czatu nie otwiera załącznika, otwórz tę samą rozmowę w przeglądarce. Nie opublikowano tego wydania w poprzednim publicznym repozytorium.
2. Zezwól wybranemu menedżerowi plików/przeglądarce na instalowanie nieznanych aplikacji. Otwórz APK i wybierz instalację lub aktualizację. Następnie możesz wyłączyć to zezwolenie.
3. Zarezerwuj co najmniej 200 MB na instalację oraz dodatkowe miejsce na prywatną kopię PDF, rozpoznane strony, obrazy i eksport. Wielkie dokumenty mogą potrzebować wielokrotności rozmiaru źródła.
4. Otwórz „Konwertuj książkę”, wybierz PDF, język OCR, formaty oraz ewentualny katalog docelowy. Język interfejsu wybiera się osobno w ustawieniach. „Automatycznie” OCR używa modeli pol+rus+eng i może być wolniejsze od jednego języka.
5. Sprawdź podgląd, ostrzeżenia i popraw rozpoznany tekst. Zapisz korektę przed zamknięciem procesu. Z rozpoznanego projektu można eksportować kolejne formaty bez ponownego OCR.

Osobne opcje służą kompresji PDF oraz utworzeniu PDF z warstwą OCR. Wybór wielu plików lub katalogu SAF tworzy sekwencyjną kolejkę. CBZ zawiera obrazy stron i sam nie wymaga OCR. Kompresja nie gwarantuje zmniejszenia pliku; aplikacja podaje rozmiary i ostrzega o podpisie cyfrowym.

## Aktualizacja z 1.1.0

Przed aktualizacją wyeksportuj otwartą książkę: stara wersja nie utrwalała niezapisanej korekty po zakończeniu procesu. Zachowano identyfikator i ikonę. Nie ma migracji niezapisanego tekstu starej aktywności do nowej bazy projektów.

Aktualizacja wymaga wyższego versionCode **i identycznego certyfikatu**. Użyty stabilny certyfikat debug ma SHA-256:

`A00DBE983485808F1A5394A98E2BC8D9B1D9B7C2BBAFD3699B1824CFBF3F4675`

Porównaj z certyfikatem faktycznie zainstalowanej wersji. Inny podpis, próba obniżenia wersji albo Android starszy niż 8.0 powodują konflikt. Nie odinstalowuj jedynej kopii danych, aby ominąć konflikt. Wynik rzeczywistego testu aktualizacji i jego zakres podano w RELEASE_REPORT.md; potwierdzenie telefonu dla 1.1 nie jest testem telefonu dla 2.0.

## Debug, release i AAB

- `debug.apk`: instalowalna wersja testowa, nie podpis produkcyjny.
- `release-qa-debug-signed.apk`: zoptymalizowany kod R8 podpisany kluczem debug wyłącznie do QA. Nie jest wydaniem produkcyjnym.
- `release-unsigned.apk`: oczekuje na właściwy podpis; nie można go bezpośrednio instalować.
- `release-unsigned.aab`: pakiet oczekujący na klucz przesyłania/konfigurację Play App Signing; nie otwiera się go na telefonie jak APK.

Podpisanie i różnice kluczy: BUILD_AND_SIGNING.md. Nie obiecujemy aktualizacji instalacji debug pakietem podpisanym innym kluczem.

## Praca w tle i dane robocze

Powiadomienie pokazuje aktywne zadanie i anulowanie. Na Androidzie 13+ możesz zezwolić na powiadomienia. Brak zgody nie daje aplikacji nieograniczonej pracy w tle. Android może zakończyć proces lub ograniczyć czas usługi; otwórz aplikację i wznów zadanie. Ukończone strony mają trwałe checkpointy. Force-stop zatrzymuje pracę do ponownego uruchomienia przez użytkownika.

Zapisaną korektę przechowuje projekt. Niezapisany duży szkic tekstu zachowuje obrót ekranu, ale nie gwarantuje odtworzenia po śmierci procesu. Zapisuj ważne zmiany. Nieużywane projekty mogą być usunięte po 30 dniach, z ostrzeżeniem co najmniej 7 dni wcześniej; aktywne zadania i niewyeksportowane korekty chronią projekt. Gotowe eksporty i historia pozostają. Kopia zapasowa Androida jest wyłączona.

OCR i rekonstrukcja układu wymagają kontroli, szczególnie dla tabel, map, przypisów, wielokolumnowych stron i słabych skanów. Limity pamięci i niepewne ilustracje są zgłaszane; „Oryginalna” nie oznacza zachowania oryginalnych bajtów każdego obrazu. Dokładne ograniczenia oraz wykonane i niewykonane testy: RELEASE_REPORT.md i TEST_REPORT.md.

Aplikacja nie ma uprawnienia INTERNET i nie wysyła dokumentów. Wybrany dostawca SAF lub odbiorca udostępnionego pliku może mieć własne połączenia sieciowe.
